import time
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

app = FastAPI()

total_hits = 0
last_reset_time = time.time()

MAX_HITS = 10
RESET_SECONDS = 120


def auto_reset():
    global total_hits, last_reset_time

    now = time.time()
    if now - last_reset_time >= RESET_SECONDS:
        total_hits = 0
        last_reset_time = now


def stats_data():
    auto_reset()
    remaining = max(0, MAX_HITS - total_hits)
    reset_in = max(0, RESET_SECONDS - int(time.time() - last_reset_time))

    return {
        "total_hits": total_hits,
        "remaining_hits": remaining,
        "reset_in": reset_in
    }


def page(title, message="System ready"):
    data = stats_data()

    return f"""
<!DOCTYPE html>
<html>
<head>
<title>{title}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {{
    margin:0;
    min-height:100vh;
    font-family:Arial, sans-serif;
    background:linear-gradient(135deg,#020617,#4c1d95,#0891b2);
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
}}

body.light {{
    background:linear-gradient(135deg,#f8fafc,#dbeafe,#f5d0fe);
    color:#0f172a;
}}

.box {{
    width:90%;
    max-width:950px;
    padding:40px;
    border-radius:32px;
    background:rgba(255,255,255,0.13);
    box-shadow:0 30px 90px rgba(0,0,0,0.45);
    backdrop-filter:blur(18px);
    text-align:center;
}}

h1 {{
    font-size:46px;
    margin:0;
    background:linear-gradient(90deg,#22d3ee,#a78bfa,#22c55e);
    -webkit-background-clip:text;
    color:transparent;
}}

.sub {{
    margin:12px 0 30px;
    color:#cbd5e1;
}}

.grid {{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:22px;
}}

.card {{
    padding:28px;
    border-radius:26px;
    background:rgba(15,23,42,0.85);
}}

body.light .card {{
    background:rgba(255,255,255,0.92);
}}

.label {{
    color:#94a3b8;
    font-size:18px;
}}

.num {{
    font-size:60px;
    font-weight:900;
    margin-top:10px;
}}

.green {{ color:#22c55e; }}
.blue {{ color:#38bdf8; }}
.orange {{ color:#fb923c; }}

button, a {{
    display:inline-block;
    margin:12px;
    padding:15px 26px;
    border:none;
    border-radius:16px;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
    color:white;
    text-decoration:none;
    background:linear-gradient(135deg,#7c3aed,#06b6d4);
}}

.reset {{
    background:linear-gradient(135deg,#ef4444,#f97316);
}}

.status {{
    margin-top:20px;
    font-size:18px;
    color:#cbd5e1;
}}
</style>
</head>

<body>
<div class="box">
    <h1>{title}</h1>
    <div class="sub">EC2 + FastAPI + CloudFront + WAF</div>

    <div class="grid">
        <div class="card">
            <div class="label">Total API Hits</div>
            <div class="num green" id="hits">{data["total_hits"]}</div>
        </div>

        <div class="card">
            <div class="label">Remaining Hits</div>
            <div class="num blue" id="remaining">{data["remaining_hits"]}</div>
        </div>

        <div class="card">
            <div class="label">Auto Reset In</div>
            <div class="num orange" id="timer">{data["reset_in"]}s</div>
        </div>
    </div>

    <br>

    <a href="/api/test">Hit API</a>
    <a class="reset" href="/reset">Reset</a>
    <button onclick="toggleTheme()">Dark / Light</button>

    <div class="status">{message}</div>
</div>

<script>
if(localStorage.getItem("theme") === "light") {{
    document.body.classList.add("light");
}}

function toggleTheme() {{
    document.body.classList.toggle("light");
    localStorage.setItem("theme", document.body.classList.contains("light") ? "light" : "dark");
}}

setTimeout(function() {{
    window.location.reload();
}}, 1000);
</script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
def dashboard():
    return page("API Hit Control Dashboard")


@app.get("/api/test", response_class=HTMLResponse)
def test_api(request: Request):
    global total_hits

    auto_reset()

    if total_hits >= MAX_HITS:
        return page("API Limit Reached", "Only 10 API hits allowed. Please wait for auto reset.")

    total_hits += 1
    return page("API Test Page", "API request processed successfully.")


@app.get("/reset", response_class=HTMLResponse)
def reset():
    global total_hits, last_reset_time

    total_hits = 0
    last_reset_time = time.time()

    return page("Counter Reset", "Total API Hits and Remaining Hits reset successfully.")


@app.get("/stats")
def stats():
    return JSONResponse(stats_data())